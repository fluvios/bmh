<?php namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AdminSettings extends Model {

	protected $guarded = array();
	public $timestamps = false;
}