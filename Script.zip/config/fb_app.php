<?php

return array(

    /*
    |--------------------------------------------------------------------------
    | Facebook App ID
    |--------------------------------------------------------------------------
    | Create your app on https://developers.facebook.com/ 
	|
    */

     //<--- Facebook App ID
    'id' => "APP_ID",
    
	//<--- Language - Check available languages ---> https://www.facebook.com/translations/FacebookLocales.xml
    'lang' => "en_US",

);
